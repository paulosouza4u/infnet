export default function soma(a,b) {
    return a+b;
}
